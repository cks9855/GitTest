﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rank
{
    public partial class weather : Form
    {
        private int p = 0;
        private int s = 0;
        private int a = 0;
        private int w = 0;

        public weather()
        {
            InitializeComponent();
        }

        private void Vote1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("'봄'을 선택하셨습니다.");
            p = p + 1;
            Calc();
        }

        private void Vote2_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("'여름'을 선택하셨습니다.");
            s = s + 1;
            Calc();
        }

        private void Vote3_Click_2(object sender, EventArgs e)
        {
            MessageBox.Show("'가을'을 선택하셨습니다.");
            a = a + 1;

            Calc();
        }

        private void Vote4_Click_3(object sender, EventArgs e)
        {
            MessageBox.Show("'겨울'을 선택하셨습니다.");
            w = w + 1;

            Calc();
        }

        private void Calc()
        {
            //int 형식의 배열 . 배열 크기 4 . p,s,a,w 초기화
            int[] RankValues = new int[4] { p, s, a, w };

            //string 형식의 배열 . 배열 크기 4 . 봄,여름,가을,겨울 초기화
            string[] RankNames = new string[4] { "봄", "여름", "가을", "겨울" };

            for (int i = 0; i < RankValues.Length; i++)
            {
                for (int j = i + 1; j < RankValues.Length; j++)
                {
                    if (RankValues[i] < RankValues[j])
                    {
                        //int 배열 중 i 번째 요소와 j 번째 요소를 바꾸는 기능

                        int t = RankValues[i];
                        RankValues[i] = RankValues[j];
                        RankValues[j] = t;

                        //string 배열 중 i 번째 요소와 j 번째 요소를 바꾸는 기능

                        string n = RankNames[i];
                        RankNames[i] = RankNames[j];
                        RankNames[j] = n;
                    }
                }
            }

            float x = p + s + a + w;
            float x1 = RankValues[0] / x * 100;
            float x2 = RankValues[1] / x * 100;
            float x3 = RankValues[2] / x * 100;
            float x4 = RankValues[3] / x * 100;
            //0 ()%
            RankValues1.Text = RankValues[0].ToString() + " ( 득표율: " + x1.ToString() + "%)";
            RankValues2.Text = RankValues[1].ToString() + " ( 득표율: " + x2.ToString() + "%)";
            RankValues3.Text = RankValues[2].ToString() + " ( 득표율: " + x3.ToString() + "%)";
            RankValues4.Text = RankValues[3].ToString() + " ( 득표율: " + x4.ToString() + "%)";
            RankValues5.Text = x.ToString() + " 표";

            RankNames1.Text = RankNames[0];
            RankNames2.Text = RankNames[1];
            RankNames3.Text = RankNames[2];
            RankNames4.Text = RankNames[3];
        }
    }
}