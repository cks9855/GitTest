﻿namespace Rank
{
    partial class weather
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(weather));
            this.title = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.Vote1 = new System.Windows.Forms.Button();
            this.Vote2 = new System.Windows.Forms.Button();
            this.Vote3 = new System.Windows.Forms.Button();
            this.Vote4 = new System.Windows.Forms.Button();
            this.RankNumber1 = new System.Windows.Forms.Label();
            this.RankNumber3 = new System.Windows.Forms.Label();
            this.RankNumber2 = new System.Windows.Forms.Label();
            this.RankValues1 = new System.Windows.Forms.Label();
            this.RankNames1 = new System.Windows.Forms.Label();
            this.RankNumber4 = new System.Windows.Forms.Label();
            this.RankNames3 = new System.Windows.Forms.Label();
            this.RankValues3 = new System.Windows.Forms.Label();
            this.RankValues2 = new System.Windows.Forms.Label();
            this.RankNames2 = new System.Windows.Forms.Label();
            this.RankValues4 = new System.Windows.Forms.Label();
            this.RankNames4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.RankValues5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // title
            // 
            this.title.BackColor = System.Drawing.Color.White;
            this.title.Enabled = false;
            this.title.Font = new System.Drawing.Font("휴먼엑스포", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.title.ForeColor = System.Drawing.Color.Black;
            this.title.Location = new System.Drawing.Point(81, 35);
            this.title.Name = "title";
            this.title.ReadOnly = true;
            this.title.Size = new System.Drawing.Size(354, 41);
            this.title.TabIndex = 0;
            this.title.Text = "당신이 좋아하는 계절은?";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(28, 118);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 100);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(153, 118);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(100, 100);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(272, 118);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(100, 100);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 3;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(396, 118);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(100, 100);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 4;
            this.pictureBox4.TabStop = false;
            // 
            // textBox2
            // 
            this.textBox2.Enabled = false;
            this.textBox2.Font = new System.Drawing.Font("나눔바른고딕OTF", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox2.Location = new System.Drawing.Point(28, 236);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(100, 26);
            this.textBox2.TabIndex = 5;
            this.textBox2.Text = "봄";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox3
            // 
            this.textBox3.Enabled = false;
            this.textBox3.Font = new System.Drawing.Font("나눔바른고딕OTF", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox3.Location = new System.Drawing.Point(153, 236);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(100, 26);
            this.textBox3.TabIndex = 6;
            this.textBox3.Text = "여름";
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox4
            // 
            this.textBox4.Enabled = false;
            this.textBox4.Font = new System.Drawing.Font("나눔바른고딕OTF", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox4.Location = new System.Drawing.Point(272, 236);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(100, 26);
            this.textBox4.TabIndex = 7;
            this.textBox4.Text = "가을";
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox5
            // 
            this.textBox5.Enabled = false;
            this.textBox5.Font = new System.Drawing.Font("나눔바른고딕OTF", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox5.Location = new System.Drawing.Point(396, 236);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(100, 26);
            this.textBox5.TabIndex = 8;
            this.textBox5.Text = "겨울";
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Vote1
            // 
            this.Vote1.BackColor = System.Drawing.Color.White;
            this.Vote1.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Vote1.Location = new System.Drawing.Point(44, 271);
            this.Vote1.Name = "Vote1";
            this.Vote1.Size = new System.Drawing.Size(70, 51);
            this.Vote1.TabIndex = 10;
            this.Vote1.Text = "투표하기\r\n(봄)";
            this.Vote1.UseVisualStyleBackColor = false;
            this.Vote1.Click += new System.EventHandler(this.Vote1_Click);
            // 
            // Vote2
            // 
            this.Vote2.BackColor = System.Drawing.Color.White;
            this.Vote2.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Vote2.Location = new System.Drawing.Point(168, 271);
            this.Vote2.Name = "Vote2";
            this.Vote2.Size = new System.Drawing.Size(70, 51);
            this.Vote2.TabIndex = 11;
            this.Vote2.Text = "투표하기\r\n(여름)";
            this.Vote2.UseVisualStyleBackColor = false;
            this.Vote2.Click += new System.EventHandler(this.Vote2_Click_1);
            // 
            // Vote3
            // 
            this.Vote3.BackColor = System.Drawing.Color.White;
            this.Vote3.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Vote3.Location = new System.Drawing.Point(290, 271);
            this.Vote3.Name = "Vote3";
            this.Vote3.Size = new System.Drawing.Size(70, 51);
            this.Vote3.TabIndex = 12;
            this.Vote3.Text = "투표하기\r\n(가을)";
            this.Vote3.UseVisualStyleBackColor = false;
            this.Vote3.Click += new System.EventHandler(this.Vote3_Click_2);
            // 
            // Vote4
            // 
            this.Vote4.BackColor = System.Drawing.Color.White;
            this.Vote4.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Vote4.Location = new System.Drawing.Point(411, 271);
            this.Vote4.Name = "Vote4";
            this.Vote4.Size = new System.Drawing.Size(70, 51);
            this.Vote4.TabIndex = 13;
            this.Vote4.Text = "투표하기\r\n(겨울)";
            this.Vote4.UseVisualStyleBackColor = false;
            this.Vote4.Click += new System.EventHandler(this.Vote4_Click_3);
            // 
            // RankNumber1
            // 
            this.RankNumber1.AutoSize = true;
            this.RankNumber1.Font = new System.Drawing.Font("나눔바른고딕OTF", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.RankNumber1.Location = new System.Drawing.Point(59, 357);
            this.RankNumber1.Name = "RankNumber1";
            this.RankNumber1.Size = new System.Drawing.Size(17, 18);
            this.RankNumber1.TabIndex = 14;
            this.RankNumber1.Text = "1";
            // 
            // RankNumber3
            // 
            this.RankNumber3.AutoSize = true;
            this.RankNumber3.Font = new System.Drawing.Font("나눔바른고딕OTF", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.RankNumber3.Location = new System.Drawing.Point(59, 428);
            this.RankNumber3.Name = "RankNumber3";
            this.RankNumber3.Size = new System.Drawing.Size(17, 18);
            this.RankNumber3.TabIndex = 15;
            this.RankNumber3.Text = "3";
            // 
            // RankNumber2
            // 
            this.RankNumber2.AutoSize = true;
            this.RankNumber2.Font = new System.Drawing.Font("나눔바른고딕OTF", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.RankNumber2.Location = new System.Drawing.Point(59, 395);
            this.RankNumber2.Name = "RankNumber2";
            this.RankNumber2.Size = new System.Drawing.Size(17, 18);
            this.RankNumber2.TabIndex = 16;
            this.RankNumber2.Text = "2";
            // 
            // RankValues1
            // 
            this.RankValues1.AutoSize = true;
            this.RankValues1.Font = new System.Drawing.Font("나눔바른고딕OTF", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.RankValues1.Location = new System.Drawing.Point(306, 357);
            this.RankValues1.Name = "RankValues1";
            this.RankValues1.Size = new System.Drawing.Size(113, 18);
            this.RankValues1.TabIndex = 17;
            this.RankValues1.Text = "0 ( 득표율: 0%)";
            // 
            // RankNames1
            // 
            this.RankNames1.AutoSize = true;
            this.RankNames1.Font = new System.Drawing.Font("나눔바른고딕OTF", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.RankNames1.Location = new System.Drawing.Point(176, 357);
            this.RankNames1.Name = "RankNames1";
            this.RankNames1.Size = new System.Drawing.Size(22, 18);
            this.RankNames1.TabIndex = 18;
            this.RankNames1.Text = "봄";
            // 
            // RankNumber4
            // 
            this.RankNumber4.AutoSize = true;
            this.RankNumber4.Font = new System.Drawing.Font("나눔바른고딕OTF", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.RankNumber4.Location = new System.Drawing.Point(59, 461);
            this.RankNumber4.Name = "RankNumber4";
            this.RankNumber4.Size = new System.Drawing.Size(17, 18);
            this.RankNumber4.TabIndex = 19;
            this.RankNumber4.Text = "4";
            // 
            // RankNames3
            // 
            this.RankNames3.AutoSize = true;
            this.RankNames3.Font = new System.Drawing.Font("나눔바른고딕OTF", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.RankNames3.Location = new System.Drawing.Point(176, 428);
            this.RankNames3.Name = "RankNames3";
            this.RankNames3.Size = new System.Drawing.Size(36, 18);
            this.RankNames3.TabIndex = 20;
            this.RankNames3.Text = "가을";
            // 
            // RankValues3
            // 
            this.RankValues3.AutoSize = true;
            this.RankValues3.Font = new System.Drawing.Font("나눔바른고딕OTF", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.RankValues3.Location = new System.Drawing.Point(306, 428);
            this.RankValues3.Name = "RankValues3";
            this.RankValues3.Size = new System.Drawing.Size(113, 18);
            this.RankValues3.TabIndex = 21;
            this.RankValues3.Text = "0 ( 득표율: 0%)";
            // 
            // RankValues2
            // 
            this.RankValues2.AutoSize = true;
            this.RankValues2.Font = new System.Drawing.Font("나눔바른고딕OTF", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.RankValues2.Location = new System.Drawing.Point(306, 395);
            this.RankValues2.Name = "RankValues2";
            this.RankValues2.Size = new System.Drawing.Size(113, 18);
            this.RankValues2.TabIndex = 22;
            this.RankValues2.Text = "0 ( 득표율: 0%)";
            // 
            // RankNames2
            // 
            this.RankNames2.AutoSize = true;
            this.RankNames2.Font = new System.Drawing.Font("나눔바른고딕OTF", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.RankNames2.Location = new System.Drawing.Point(176, 395);
            this.RankNames2.Name = "RankNames2";
            this.RankNames2.Size = new System.Drawing.Size(36, 18);
            this.RankNames2.TabIndex = 23;
            this.RankNames2.Text = "여름";
            // 
            // RankValues4
            // 
            this.RankValues4.AutoSize = true;
            this.RankValues4.Font = new System.Drawing.Font("나눔바른고딕OTF", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.RankValues4.Location = new System.Drawing.Point(306, 461);
            this.RankValues4.Name = "RankValues4";
            this.RankValues4.Size = new System.Drawing.Size(113, 18);
            this.RankValues4.TabIndex = 24;
            this.RankValues4.Text = "0 ( 득표율: 0%)";
            // 
            // RankNames4
            // 
            this.RankNames4.AutoSize = true;
            this.RankNames4.Font = new System.Drawing.Font("나눔바른고딕OTF", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.RankNames4.Location = new System.Drawing.Point(176, 461);
            this.RankNames4.Name = "RankNames4";
            this.RankNames4.Size = new System.Drawing.Size(36, 18);
            this.RankNames4.TabIndex = 25;
            this.RankNames4.Text = "겨울";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("나눔바른고딕OTF", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.Location = new System.Drawing.Point(18, 14);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(95, 18);
            this.label5.TabIndex = 26;
            this.label5.Text = "전체 투표 수 :";
            // 
            // RankValues5
            // 
            this.RankValues5.AutoSize = true;
            this.RankValues5.Font = new System.Drawing.Font("나눔바른고딕OTF", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.RankValues5.Location = new System.Drawing.Point(119, 13);
            this.RankValues5.Name = "RankValues5";
            this.RankValues5.Size = new System.Drawing.Size(17, 18);
            this.RankValues5.TabIndex = 27;
            this.RankValues5.Text = "0";
            // 
            // weather
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(518, 498);
            this.Controls.Add(this.RankValues5);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.RankNames4);
            this.Controls.Add(this.RankValues4);
            this.Controls.Add(this.RankNames2);
            this.Controls.Add(this.RankValues2);
            this.Controls.Add(this.RankValues3);
            this.Controls.Add(this.RankNames3);
            this.Controls.Add(this.RankNumber4);
            this.Controls.Add(this.RankNames1);
            this.Controls.Add(this.RankValues1);
            this.Controls.Add(this.RankNumber2);
            this.Controls.Add(this.RankNumber3);
            this.Controls.Add(this.RankNumber1);
            this.Controls.Add(this.Vote4);
            this.Controls.Add(this.Vote3);
            this.Controls.Add(this.Vote2);
            this.Controls.Add(this.Vote1);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.title);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "weather";
            this.Text = "weather";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox title;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Button Vote1;
        private System.Windows.Forms.Button Vote2;
        private System.Windows.Forms.Button Vote3;
        private System.Windows.Forms.Button Vote4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label RankNumber1;
        private System.Windows.Forms.Label RankNumber3;
        private System.Windows.Forms.Label RankNumber2;
        private System.Windows.Forms.Label RankValues1;
        private System.Windows.Forms.Label RankNames1;
        private System.Windows.Forms.Label RankNumber4;
        private System.Windows.Forms.Label RankNames3;
        private System.Windows.Forms.Label RankValues3;
        private System.Windows.Forms.Label RankValues2;
        private System.Windows.Forms.Label RankNames2;
        private System.Windows.Forms.Label RankValues4;
        private System.Windows.Forms.Label RankNames4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label RankValues5;
    }
}